# ==============================================
# TeleMirror - Quick Deploy to VPS (Windows)
# ==============================================

# Check PowerShell version
if ($PSVersionTable.PSVersion.Major -lt 3) {
    Write-Host "Need PowerShell version 3.0 or higher" -ForegroundColor Red
    exit 1
}

# Color functions
function Write-Info { param($Message) Write-Host "[INFO] $Message" -ForegroundColor Green }
function Write-Warn { param($Message) Write-Host "[WARN] $Message" -ForegroundColor Yellow }
function Write-Error { param($Message) Write-Host "[ERROR] $Message" -ForegroundColor Red }
function Write-Step { param($Message) Write-Host "[STEP] $Message" -ForegroundColor Blue }
function Write-Success { param($Message) Write-Host "[SUCCESS] $Message" -ForegroundColor Magenta }

# Function to read input
function Read-InputValue {
    param(
        [string]$Prompt,
        [string]$Default = ""
    )
    
    if ($Default) {
        $userInput = Read-Host "$Prompt (default: $Default)"
        if ([string]::IsNullOrEmpty($userInput)) {
            return $Default
        }
        return $userInput
    } else {
        return Read-Host $Prompt
    }
}

# Header
Write-Host ""
Write-Host "==================================================" -ForegroundColor Magenta
Write-Host "TeleMirror - Quick Deploy to VPS (Windows)" -ForegroundColor Magenta
Write-Host "==================================================" -ForegroundColor Magenta
Write-Host ""

# Step 1: VPS connection settings
Write-Step "1. VPS Connection Settings"
$VPS_HOST = Read-InputValue "VPS IP Address"
$VPS_USERNAME = Read-InputValue "SSH Username" "root"
$SSH_KEY_PATH = Read-InputValue "SSH Key Path" "$env:USERPROFILE\.ssh\id_rsa"

# Step 2: Telegram settings
Write-Step "2. Telegram API Settings"
$API_ID = Read-InputValue "API_ID (from https://my.telegram.org/apps)"
$API_HASH = Read-InputValue "API_HASH (from https://my.telegram.org/apps)"
$SESSION_STRING = Read-InputValue "SESSION_STRING (get via: python login.py)"

# Step 3: Channel settings
Write-Step "3. Channel Settings"
Write-Info "Channel ID format: -100XXXXXXXXX"
Write-Info "To get channel ID, add @userinfobot to your channel"
$SOURCE_CHAT_ID = Read-InputValue "Source Channel ID"
$TARGET_CHAT_ID = Read-InputValue "Target Channel ID"

# Step 4: Additional settings
Write-Step "4. Additional Settings"
$PORT_API = Read-InputValue "Application Port" "8000"
$PORT_PG = Read-InputValue "PostgreSQL Port" "5432"
$LOG_LEVEL = Read-InputValue "Log Level" "INFO"

# Step 5: Proxy settings (optional)
Write-Step "5. Proxy Settings (optional)"
$USE_PROXY = Read-InputValue "Use proxy? (y/n)" "n"

$PROXY_CONFIG = ""
if ($USE_PROXY -eq "y" -or $USE_PROXY -eq "Y") {
    $PROXY_TYPE = Read-InputValue "Proxy Type (socks5/socks4/http)" "socks5"
    $PROXY_HOST = Read-InputValue "Proxy Host" "127.0.0.1"
    $PROXY_PORT = Read-InputValue "Proxy Port" "1080"
    $PROXY_USERNAME = Read-InputValue "Proxy Username (optional)"
    $PROXY_PASSWORD = Read-InputValue "Proxy Password (optional)"
    
    $PROXY_CONFIG = "`nPROXY_TYPE=$PROXY_TYPE`nPROXY_HOST=$PROXY_HOST`nPROXY_PORT=$PROXY_PORT"
    
    if (![string]::IsNullOrEmpty($PROXY_USERNAME)) {
        $PROXY_CONFIG += "`nPROXY_USERNAME=$PROXY_USERNAME`nPROXY_PASSWORD=$PROXY_PASSWORD"
    }
}

# Step 6: Create .env file
Write-Step "6. Creating .env file"
$envContent = @"
# ==============================================
# TeleMirror - Deploy Configuration
# ==============================================

# Telegram API
API_ID=$API_ID
API_HASH=$API_HASH
SESSION_STRING=$SESSION_STRING

# Database
USE_MEMORY_DB=false

# Channel mapping
CHAT_MAPPING=[$SOURCE_CHAT_ID`:$TARGET_CHAT_ID]

# Settings
LOG_LEVEL=$LOG_LEVEL
HOST=0.0.0.0
PORT=$PORT_API

# Docker ports
PORT_PG=$PORT_PG
PORT_API=$PORT_API

# Repeat settings
REPEAT_INTERVAL=300
REPEAT_COUNT=3$PROXY_CONFIG
"@

$envContent | Out-File -FilePath ".env" -Encoding UTF8
Write-Success ".env file created successfully!"

# Step 7: Check SSH connection
Write-Step "7. Checking SSH Connection"
Write-Info "Testing SSH connection to VPS..."

# Check if SSH key exists
if (!(Test-Path $SSH_KEY_PATH)) {
    Write-Error "SSH key not found: $SSH_KEY_PATH"
    Write-Info "Create SSH key or specify correct path"
    exit 1
}

# Test SSH connection
try {
    $testConnection = ssh -i $SSH_KEY_PATH -o ConnectTimeout=10 -o BatchMode=yes "$VPS_USERNAME@$VPS_HOST" "exit" 2>$null
    if ($LASTEXITCODE -ne 0) {
        throw "SSH connection failed"
    }
    Write-Success "SSH connection successful!"
} catch {
    Write-Error "Failed to connect to VPS via SSH"
    Write-Info "Check:"
    Write-Info "- VPS IP: $VPS_HOST"
    Write-Info "- SSH key: $SSH_KEY_PATH"
    Write-Info "- Username: $VPS_USERNAME"
    Write-Info "- SSH access allowed on VPS"
    exit 1
}

# Step 8: Prepare files
Write-Step "8. Preparing files for deployment"
$archiveName = "telemirror-deploy.tar.gz"

# Remove old archive if exists
if (Test-Path $archiveName) {
    Remove-Item $archiveName -Force
}

# Create archive (requires tar in Windows 10+)
Write-Info "Creating archive..."
$tarCommand = "tar -czf $archiveName --exclude=venv --exclude=__pycache__ --exclude=*.pyc --exclude=.git ."

try {
    Invoke-Expression $tarCommand
    Write-Success "Archive created successfully!"
} catch {
    Write-Error "Error creating archive. Make sure tar is available in Windows"
    Write-Info "Alternative: use WSL or Git Bash"
    exit 1
}

# Step 9: Copy to VPS
Write-Step "9. Copying files to VPS"
try {
    scp -i $SSH_KEY_PATH $archiveName "$VPS_USERNAME@$VPS_HOST`:/tmp/" 2>$null
    if ($LASTEXITCODE -ne 0) {
        throw "SCP failed"
    }
    Write-Success "Files copied to VPS!"
} catch {
    Write-Error "Error copying files to VPS"
    exit 1
}

# Step 10: Deploy on VPS
Write-Step "10. Deploying on VPS"
$deployScript = @"
set -e
mkdir -p /home/$VPS_USERNAME/telemirror
cd /home/$VPS_USERNAME/telemirror
tar -xzf /tmp/$archiveName
rm /tmp/$archiveName
if ! command -v docker >/dev/null 2>&1; then
    echo "Installing Docker..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    systemctl enable docker
    systemctl start docker
    rm get-docker.sh
fi
if ! command -v docker-compose >/dev/null 2>&1; then
    echo "Installing Docker Compose..."
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-`$(uname -s)-`$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
fi
echo "Stopping old containers..."
docker-compose down || true
echo "Starting containers..."
docker-compose up -d --build
echo "Cleaning up..."
docker system prune -f
echo "Deploy completed!"
echo "Container status:"
docker-compose ps
"@

try {
    ssh -i $SSH_KEY_PATH "$VPS_USERNAME@$VPS_HOST" $deployScript
    if ($LASTEXITCODE -ne 0) {
        throw "Deploy failed"
    }
} catch {
    Write-Error "Error during deployment"
    exit 1
}

# Cleanup local archive
Remove-Item $archiveName -Force

# Final info
Write-Success "Deploy completed successfully!"
Write-Host ""
Write-Host "==================================================" -ForegroundColor Green
Write-Host "Your application is available at:" -ForegroundColor Green
Write-Host "   http://$VPS_HOST`:$PORT_API" -ForegroundColor Green
Write-Host ""
Write-Host "Useful commands:" -ForegroundColor Green
Write-Host "   Logs: ssh -i $SSH_KEY_PATH $VPS_USERNAME@$VPS_HOST 'cd /home/$VPS_USERNAME/telemirror && docker-compose logs -f'" -ForegroundColor Green
Write-Host "   Status: ssh -i $SSH_KEY_PATH $VPS_USERNAME@$VPS_HOST 'cd /home/$VPS_USERNAME/telemirror && docker-compose ps'" -ForegroundColor Green
Write-Host "   Restart: ssh -i $SSH_KEY_PATH $VPS_USERNAME@$VPS_HOST 'cd /home/$VPS_USERNAME/telemirror && docker-compose restart'" -ForegroundColor Green
Write-Host "   Update: .\quick-deploy.ps1" -ForegroundColor Green
Write-Host "==================================================" -ForegroundColor Green 